/* ============================================================
   AGENDA ESCRIME — Worker Cloudflare tout-en-un
   Sert la page ET sauvegarde les données pour tout le monde.
   Nécessite un "binding" KV nommé : AGENDA  (voir LISEZMOI)
   ============================================================ */

const CLE_DONNEES = "agenda-escrime-2026-2027";

const PAGE_HTML = `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Agenda Escrime — Saison 2026–2027</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@75..100,400..900&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
  :root{
    --piste:#F2F3F5;
    --ink:#171A20;
    --ligne:#C9CDD4;
    --rouge:#D6222B;         /* lampe de touche rouge — M17 */
    --vert:#1F8A3B;          /* lampe de touche verte — M20 */
    --acier:#5A6270;
    --blanc:#FFFFFF;
    --ambre:#B7791F;         /* en suspens */
    --confirme:#1F8A3B;
    /* niveaux */
    --niv-regional:#5A6270;
    --niv-national:#1C4FA0;
    --niv-europeen:#6B3FA0;
    --niv-international:#B0342C;
    --radius:10px;
  }
  *{box-sizing:border-box;margin:0;padding:0;}
  html{scroll-behavior:smooth;}
  @media (prefers-reduced-motion: reduce){ html{scroll-behavior:auto;} *{transition:none !important;animation:none !important;} }
  body{
    background:var(--piste);
    color:var(--ink);
    font-family:'IBM Plex Sans', system-ui, sans-serif;
    font-size:15px;
    line-height:1.5;
  }
  /* ---------- entête ---------- */
  header{
    position:sticky; top:0; z-index:50;
    background:var(--ink); color:var(--blanc);
    display:flex; align-items:center; justify-content:space-between; gap:16px;
    padding:14px 22px;
    border-bottom:3px solid var(--rouge);
  }
  .titre{
    font-family:'Archivo', system-ui, sans-serif;
    font-variation-settings:"wdth" 78, "wght" 800;
    font-size:clamp(18px, 3vw, 26px);
    text-transform:uppercase; letter-spacing:.04em;
    display:flex; align-items:baseline; gap:12px; flex-wrap:wrap;
  }
  .titre small{
    font-family:'IBM Plex Sans', sans-serif;
    font-weight:500; font-size:12px; letter-spacing:.14em;
    color:#9AA1AD; text-transform:uppercase;
  }
  .btn-ajout{
    font-family:'Archivo', sans-serif;
    font-variation-settings:"wdth" 82, "wght" 700;
    text-transform:uppercase; letter-spacing:.06em;
    background:var(--rouge); color:#fff; border:none;
    padding:10px 18px; border-radius:6px; font-size:13px;
    cursor:pointer; white-space:nowrap;
    transition:transform .12s ease, background .12s ease;
  }
  .btn-ajout:hover{ background:#b81b23; transform:translateY(-1px); }
  .btn-ajout:focus-visible{ outline:3px solid #fff; outline-offset:2px; }

  /* ---------- filtres ---------- */
  .zone-filtres{ max-width:860px; margin:20px auto 0; padding:0 18px; display:flex; flex-direction:column; gap:8px; }
  .filtres{ display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
  .filtres > span{ font-size:12px; text-transform:uppercase; letter-spacing:.12em; color:var(--acier); width:74px; flex:none; }
  .chip{
    border:1.5px solid var(--ligne); background:var(--blanc); color:var(--ink);
    padding:6px 14px; border-radius:999px; cursor:pointer; font-size:13px; font-weight:600;
    transition:all .12s ease;
  }
  .chip:focus-visible{ outline:3px solid var(--ink); outline-offset:2px; }
  .chip.actif{ background:var(--ink); color:#fff; border-color:var(--ink); }
  .chip .lampe{ display:inline-block; width:9px; height:9px; border-radius:50%; margin-right:6px; vertical-align:1px; }
  .lampe.m17{ background:var(--rouge); } .lampe.m20{ background:var(--vert); } .lampe.autre{ background:var(--acier); }
  .lampe.regional{ background:var(--niv-regional); }
  .lampe.national{ background:var(--niv-national); }
  .lampe.europeen{ background:var(--niv-europeen); }
  .lampe.international{ background:var(--niv-international); }

  .legende{
    max-width:860px; margin:10px auto 0; padding:0 18px;
    display:flex; gap:14px; flex-wrap:wrap;
    font-size:12px; color:var(--acier);
  }
  .legende b{ font-weight:600; }
  .legende .ic{ margin-right:4px; }

  /* ---------- la piste (agenda) ---------- */
  main{ max-width:860px; margin:0 auto; padding:10px 18px 80px; }
  .mois{ margin-top:34px; }
  .mois > h2{
    font-family:'Archivo', sans-serif;
    font-variation-settings:"wdth" 75, "wght" 850;
    font-size:22px; text-transform:uppercase; letter-spacing:.05em;
    display:flex; align-items:center; gap:14px;
  }
  .mois > h2::after{ content:""; flex:1; height:2px; background:var(--ink); opacity:.85; }
  .mois > h2 em{ font-style:normal; font-family:'IBM Plex Sans'; font-weight:500; font-size:12px; letter-spacing:.14em; color:var(--acier); }

  .weekend{
    display:grid; grid-template-columns:86px 1fr; gap:0 18px;
    padding:12px 0; border-bottom:1px dashed var(--ligne);
  }
  .weekend:last-child{ border-bottom:none; }
  .dates{
    font-family:'Archivo', sans-serif;
    font-variation-settings:"wdth" 78, "wght" 800;
    font-size:20px; line-height:1.1; padding-top:2px;
    border-left:3px solid var(--ligne); padding-left:12px;
  }
  .weekend.occupe .dates{ border-left-color:var(--ink); }
  .dates small{ display:block; font-family:'IBM Plex Sans'; font-weight:500; font-size:10.5px; letter-spacing:.12em; text-transform:uppercase; color:var(--acier); margin-top:2px; }
  .weekend.libre .dates{ color:#A7ADB8; }
  .libre-label{ align-self:center; font-size:12.5px; color:#A7ADB8; font-style:italic; }

  .evts{ display:flex; flex-direction:column; gap:8px; }
  .evt{
    background:var(--blanc); border:1px solid var(--ligne); border-radius:var(--radius);
    padding:10px 14px; display:flex; align-items:flex-start; gap:12px;
    position:relative; cursor:pointer;
    box-shadow:0 1px 2px rgba(23,26,32,.05);
    transition:box-shadow .12s ease, transform .12s ease;
    text-align:left; width:100%;
    font-family:inherit; font-size:inherit; color:inherit;
  }
  .evt:hover{ box-shadow:0 3px 10px rgba(23,26,32,.12); transform:translateY(-1px); }
  .evt:focus-visible{ outline:3px solid var(--ink); outline-offset:2px; }
  .evt .lampe-touche{
    width:12px; height:12px; border-radius:50%; margin-top:5px; flex:none;
    box-shadow:0 0 0 3px rgba(0,0,0,.05);
  }
  .evt.m17 .lampe-touche{ background:var(--rouge); box-shadow:0 0 8px rgba(214,34,43,.45); }
  .evt.m20 .lampe-touche{ background:var(--vert); box-shadow:0 0 8px rgba(31,138,59,.45); }
  .evt.autre .lampe-touche{ background:var(--acier); }
  .evt-corps{ flex:1; min-width:0; }
  .evt-nom{ font-weight:600; font-size:14.5px; }
  .evt-lieu{ font-size:12.5px; color:var(--acier); }
  .badges{ display:flex; gap:6px; flex-wrap:wrap; align-items:center; flex:none; justify-content:flex-end; }
  .badge{
    font-family:'Archivo', sans-serif; font-variation-settings:"wdth" 85, "wght" 700;
    font-size:11px; letter-spacing:.08em; text-transform:uppercase;
    padding:3px 9px; border-radius:5px; color:#fff;
  }
  .badge.m17{ background:var(--rouge); } .badge.m20{ background:var(--vert); } .badge.autre{ background:var(--acier); }

  /* ---- badges de niveau ---- */
  .badge.niv{ background:transparent; }
  .badge.niv.regional{ color:var(--niv-regional); border:1.5px solid var(--niv-regional); }
  .badge.niv.national{ color:var(--niv-national); border:1.5px solid var(--niv-national); }
  .badge.niv.europeen{ color:var(--niv-europeen); border:1.5px solid var(--niv-europeen); }
  .badge.niv.international{ color:var(--niv-international); border:1.5px solid var(--niv-international); }

  /* ---- statuts de participation ---- */
  .badge.st-confirme{ background:transparent; color:var(--confirme); border:1.5px solid var(--confirme); }
  .badge.st-suspens{ background:transparent; color:var(--ambre); border:1.5px dashed var(--ambre); }
  .badge.st-annule{ background:transparent; color:#98A0AC; border:1.5px solid #C4C9D2; }
  .evt.statut-confirme{ border-color:var(--confirme); border-width:1.5px; }
  .evt.statut-suspens{ border-color:var(--ambre); border-style:dashed; border-width:1.5px; }
  .evt.statut-annule{ opacity:.55; }
  .evt.statut-annule .evt-nom{ text-decoration:line-through; text-decoration-thickness:1.5px; }

  /* ---------- modales ---------- */
  .voile{
    position:fixed; inset:0; background:rgba(23,26,32,.55);
    display:none; align-items:center; justify-content:center; z-index:100; padding:18px;
  }
  .voile.ouvert{ display:flex; }
  .modale{
    background:var(--blanc); border-radius:14px; width:100%; max-width:460px;
    padding:24px; box-shadow:0 20px 60px rgba(0,0,0,.3);
    border-top:5px solid var(--rouge);
    max-height:90vh; overflow-y:auto;
  }
  .modale h3{
    font-family:'Archivo', sans-serif; font-variation-settings:"wdth" 78, "wght" 800;
    text-transform:uppercase; letter-spacing:.04em; font-size:19px; margin-bottom:4px;
  }
  .modale .sous-titre{ font-size:13px; color:var(--acier); margin-bottom:16px; }
  .champ{ margin-bottom:14px; }
  .champ label{ display:block; font-size:12px; font-weight:600; text-transform:uppercase; letter-spacing:.1em; color:var(--acier); margin-bottom:5px; }
  .champ input, .champ select{
    width:100%; padding:10px 12px; border:1.5px solid var(--ligne); border-radius:8px;
    font-family:inherit; font-size:14px; background:#FAFBFC;
  }
  .champ input:focus, .champ select:focus{ outline:none; border-color:var(--ink); background:#fff; }
  .cat-choix{ display:flex; gap:8px; flex-wrap:wrap; }
  .cat-choix button{
    flex:1; min-width:80px; padding:9px 4px; border-radius:8px; border:1.5px solid var(--ligne);
    background:#FAFBFC; font-weight:700; font-size:12.5px; cursor:pointer;
    font-family:'Archivo', sans-serif; letter-spacing:.04em;
  }
  .cat-choix button.actif.c-m17{ background:var(--rouge); border-color:var(--rouge); color:#fff; }
  .cat-choix button.actif.c-m20{ background:var(--vert); border-color:var(--vert); color:#fff; }
  .cat-choix button.actif.c-autre{ background:var(--acier); border-color:var(--acier); color:#fff; }
  .cat-choix button.actif.n-regional{ background:var(--niv-regional); border-color:var(--niv-regional); color:#fff; }
  .cat-choix button.actif.n-national{ background:var(--niv-national); border-color:var(--niv-national); color:#fff; }
  .cat-choix button.actif.n-europeen{ background:var(--niv-europeen); border-color:var(--niv-europeen); color:#fff; }
  .cat-choix button.actif.n-international{ background:var(--niv-international); border-color:var(--niv-international); color:#fff; }
  .modale-actions{ display:flex; gap:10px; margin-top:20px; }
  .modale-actions button{
    flex:1; padding:11px 0; border-radius:8px; font-size:14px; font-weight:700; cursor:pointer;
    font-family:'Archivo', sans-serif; letter-spacing:.05em; text-transform:uppercase;
  }
  .btn-annuler{ background:transparent; border:1.5px solid var(--ligne); color:var(--acier); }
  .btn-valider{ background:var(--ink); border:1.5px solid var(--ink); color:#fff; }
  .btn-valider:hover{ background:#000; }

  /* menu au clic sur une compétition */
  .menu-liste{ display:flex; flex-direction:column; gap:10px; margin-top:10px; }
  .menu-liste button{
    display:flex; align-items:center; gap:12px;
    padding:13px 15px; border-radius:10px; cursor:pointer;
    border:1.5px solid var(--ligne); background:#FAFBFC;
    font-family:inherit; font-size:14.5px; font-weight:600; text-align:left;
    transition:all .1s ease;
  }
  .menu-liste button:hover{ transform:translateX(3px); }
  .menu-liste button:focus-visible{ outline:3px solid var(--ink); outline-offset:2px; }
  .menu-liste .ic{ font-size:18px; width:24px; text-align:center; flex:none; }
  .menu-liste button small{ display:block; font-weight:400; font-size:12px; color:var(--acier); }
  .menu-liste .s-confirme.select{ border-color:var(--confirme); background:#EAF6EE; }
  .menu-liste .s-suspens.select{ border-color:var(--ambre); background:#FBF3E4; border-style:dashed; }
  .menu-liste .s-annule.select{ border-color:#98A0AC; background:#EEF0F2; }
  .menu-liste .s-aucun.select{ border-color:var(--ink); background:#EEF0F2; }
  .lien-suppr, .lien-retablir{
    margin-top:14px; width:100%; background:none; border:none; cursor:pointer;
    font-size:13px; font-weight:600; text-decoration:underline;
  }
  .lien-suppr{ color:var(--rouge); }
  .lien-retablir{ color:var(--acier); margin-top:8px; }

  .note-stockage{
    max-width:860px; margin:8px auto 0; padding:0 18px;
    font-size:12px; color:var(--acier); display:none;
  }
  .note-stockage.visible{ display:block; }

  @media (max-width:560px){
    .weekend{ grid-template-columns:64px 1fr; gap:0 12px; }
    .dates{ font-size:16px; padding-left:9px; }
    .evt{ flex-wrap:wrap; }
    .badges{ width:100%; margin-left:24px; justify-content:flex-start; }
    header{ padding:12px 14px; }
    .filtres > span{ width:100%; }
  }
</style>
</head>
<body>

<header>
  <div class="titre">Saison d'escrime <small>2026 – 2027 · M17 &amp; M20</small></div>
  <button class="btn-ajout" id="btnOuvrir">+ Ajouter un événement</button>
</header>

<div class="zone-filtres">
  <div class="filtres" role="group" aria-label="Filtrer par catégorie">
    <span>Catégorie</span>
    <button class="chip actif" data-type="cat" data-filtre="tous">Toutes</button>
    <button class="chip" data-type="cat" data-filtre="m17"><span class="lampe m17"></span>M17</button>
    <button class="chip" data-type="cat" data-filtre="m20"><span class="lampe m20"></span>M20</button>
  </div>
  <div class="filtres" role="group" aria-label="Filtrer par niveau">
    <span>Niveau</span>
    <button class="chip actif" data-type="niv" data-filtre="tous">Tous</button>
    <button class="chip" data-type="niv" data-filtre="regional"><span class="lampe regional"></span>Régional</button>
    <button class="chip" data-type="niv" data-filtre="national"><span class="lampe national"></span>National</button>
    <button class="chip" data-type="niv" data-filtre="europeen"><span class="lampe europeen"></span>Européen</button>
    <button class="chip" data-type="niv" data-filtre="international"><span class="lampe international"></span>International</button>
  </div>
</div>
<div class="legende">
  <span><span class="ic">🤺</span><b>Clique sur une compétition</b> pour changer le statut ou la modifier</span>
  <span><span class="ic">✅</span>Je la fais</span>
  <span><span class="ic">🤔</span>En suspens</span>
  <span><span class="ic">✖️</span>Je ne la fais pas</span>
</div>
<p class="note-stockage" id="noteStockage">⚠ Les modifications ne seront pas conservées après fermeture de la page dans cet environnement.</p>

<main id="agenda"></main>

<!-- Modale menu (choix au clic sur une compétition) -->
<div class="voile" id="voileMenu">
  <div class="modale" role="dialog" aria-modal="true" aria-labelledby="titreMenu">
    <h3 id="titreMenu">—</h3>
    <p class="sous-titre" id="sousTitreMenu"></p>
    <div class="menu-liste">
      <button id="btnVersStatut"><span class="ic">🎯</span><span>Modifier le statut<small>Je la fais · en suspens · je ne la fais pas</small></span></button>
      <button id="btnVersEdition"><span class="ic">✏️</span><span>Modifier la compétition<small>Nom, lieu, week-end, catégorie, niveau</small></span></button>
    </div>
    <button class="lien-suppr" id="btnSupprEvt" style="display:none;">Supprimer cet événement</button>
    <div class="modale-actions">
      <button class="btn-annuler" id="btnFermerMenu">Fermer</button>
    </div>
  </div>
</div>

<!-- Modale de statut -->
<div class="voile" id="voileStatut">
  <div class="modale" role="dialog" aria-modal="true" aria-labelledby="titreStatut">
    <h3 id="titreStatut">—</h3>
    <p class="sous-titre" id="sousTitreStatut"></p>
    <div class="menu-liste" id="statutListe">
      <button class="s-confirme" data-statut="confirme"><span class="ic">✅</span><span>Je la fais<small>Participation confirmée</small></span></button>
      <button class="s-suspens" data-statut="suspens"><span class="ic">🤔</span><span>En suspens<small>Pas encore décidé / sélection incertaine</small></span></button>
      <button class="s-annule" data-statut="annule"><span class="ic">✖️</span><span>Je ne la fais pas<small>Reste visible mais barrée</small></span></button>
      <button class="s-aucun" data-statut=""><span class="ic">↺</span><span>Aucun statut<small>Revenir à l'affichage normal</small></span></button>
    </div>
    <div class="modale-actions">
      <button class="btn-annuler" id="btnFermerStatut">Retour</button>
    </div>
  </div>
</div>

<!-- Modale ajout / édition -->
<div class="voile" id="voileAjout">
  <div class="modale" role="dialog" aria-modal="true" aria-labelledby="titreAjout">
    <h3 id="titreAjout">Ajouter un événement</h3>
    <div class="champ" style="margin-top:14px;">
      <label for="selWeekend">Week-end</label>
      <select id="selWeekend"></select>
    </div>
    <div class="champ">
      <label for="inpNom">Nom de la compétition</label>
      <input type="text" id="inpNom" placeholder="Ex. Coupe du monde à Budapest" maxlength="80">
    </div>
    <div class="champ">
      <label for="inpLieu">Lieu (optionnel)</label>
      <input type="text" id="inpLieu" placeholder="Ex. Budapest, Hongrie" maxlength="60">
    </div>
    <div class="champ">
      <label>Catégorie</label>
      <div class="cat-choix" id="catChoix">
        <button class="c-m17 actif" data-cat="m17">M17</button>
        <button class="c-m20" data-cat="m20">M20</button>
        <button class="c-autre" data-cat="autre">Autre</button>
      </div>
    </div>
    <div class="champ">
      <label>Niveau</label>
      <div class="cat-choix" id="nivChoix">
        <button class="n-regional actif" data-niv="regional">Régional</button>
        <button class="n-national" data-niv="national">National</button>
        <button class="n-europeen" data-niv="europeen">Européen</button>
        <button class="n-international" data-niv="international">International</button>
      </div>
    </div>
    <button class="lien-retablir" id="btnRetablir" style="display:none;">↺ Rétablir la version d'origine</button>
    <div class="modale-actions">
      <button class="btn-annuler" id="btnAnnulerAjout">Annuler</button>
      <button class="btn-valider" id="btnValider">Ajouter</button>
    </div>
  </div>
</div>

<script>
/* ================== DONNÉES DE LA SAISON ================== */
/* niv : regional | national | europeen | international */
const EVENEMENTS_SAISON = [
  // ---- SEPTEMBRE 2026 ----
  { id:'s01', we:'2026-09-19', cat:'m20', niv:'regional', nom:'IDF n°1', lieu:'Île-de-France' },
  { id:'s02', we:'2026-09-26', cat:'m17', niv:'regional', nom:'IDF n°1', lieu:'Île-de-France' },
  // ---- OCTOBRE ----
  { id:'s03', we:'2026-10-10', cat:'m17', niv:'national', nom:'Épreuve nationale n°1', lieu:'Étampes' },
  { id:'s04', we:'2026-10-10', cat:'m20', niv:'national', nom:'Épreuve nationale n°1', lieu:'Étampes' },
  { id:'s05', we:'2026-10-17', cat:'m17', niv:'international', nom:'Coupe du monde (date possible)', lieu:'Slovaquie ou Tunisie' },
  { id:'s06', we:'2026-10-24', cat:'m17', niv:'international', nom:'Coupe du monde (date possible)', lieu:'Slovaquie ou Tunisie' },
  // ---- NOVEMBRE ----
  { id:'s07', we:'2026-11-07', cat:'m17', niv:'international', nom:'Coupe du monde', lieu:'Hongrie' },
  { id:'s08', we:'2026-11-14', cat:'m17', niv:'national', nom:'Épreuve nationale n°2', lieu:'Muret' },
  { id:'s09', we:'2026-11-14', cat:'m20', niv:'national', nom:'Épreuve nationale n°2', lieu:'Muret' },
  { id:'s10', we:'2026-11-28', cat:'m17', niv:'regional', nom:'IDF n°2', lieu:'Île-de-France' },
  { id:'s11', we:'2026-11-28', cat:'m17', niv:'international', nom:'Coupe du monde', lieu:'Tunis' },
  // ---- DÉCEMBRE ----
  { id:'s12', we:'2026-12-05', cat:'m17', niv:'europeen', nom:'Circuit européen (CE)', lieu:'Cabriès' },
  { id:'s13', we:'2026-12-12', cat:'m20', niv:'regional', nom:'IDF n°2', lieu:'Île-de-France' },
  { id:'s14', we:'2026-12-19', cat:'m17', niv:'international', nom:'Coupe du monde', lieu:'Géorgie' },
  // ---- JANVIER 2027 ----
  { id:'s15', we:'2027-01-09', cat:'m17', niv:'international', nom:'Coupe du monde', lieu:'Émirats arabes unis' },
  { id:'s16', we:'2027-01-09', cat:'m20', niv:'regional', nom:'Championnat Île-de-France', lieu:'Individuel & équipe' },
  { id:'s17', we:'2027-01-23', cat:'m17', niv:'international', nom:'Coupe du monde', lieu:'Bangkok' },
  { id:'s18', we:'2027-01-30', cat:'m17', niv:'national', nom:'Épreuve nationale n°3', lieu:'Calais' },
  { id:'s19', we:'2027-01-30', cat:'m20', niv:'national', nom:'Épreuve nationale n°3', lieu:'Calais' },
  // ---- FÉVRIER ----
  { id:'s20', we:'2027-02-06', cat:'m17', niv:'europeen', nom:"Championnats d'Europe", lieu:'Semaine du 6 au 14 février' },
  { id:'s21', we:'2027-02-13', cat:'m17', niv:'europeen', nom:"Championnats d'Europe", lieu:'Semaine du 6 au 14 février' },
  { id:'s22', we:'2027-02-27', cat:'m17', niv:'regional', nom:'Championnat IDF', lieu:'Individuel + par équipe' },
  // ---- MARS ----
  { id:'s23', we:'2027-03-13', cat:'m17', niv:'national', nom:'Épreuve nationale n°4', lieu:'Aix' },
  { id:'s24', we:'2027-03-13', cat:'m20', niv:'national', nom:'Épreuve nationale n°4', lieu:'Aix' },
  // ---- AVRIL ----
  { id:'s25', we:'2027-04-03', cat:'m17', niv:'international', nom:'Championnats du monde (date possible)', lieu:'Week-end du 3-4 avril' },
  { id:'s26', we:'2027-04-10', cat:'m17', niv:'international', nom:'Championnats du monde (date possible)', lieu:'Week-end du 10-11 avril' },
  // ---- MAI ----
  { id:'s27', we:'2027-05-08', cat:'m17', niv:'national', nom:'Championnats de France', lieu:'Cabriès' },
  { id:'s28', we:'2027-05-08', cat:'m20', niv:'national', nom:'Championnats de France', lieu:'Cabriès' },
];

/* ================== GÉNÉRATION DES WEEK-ENDS ================== */
const MOIS_FR = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];

function genererWeekends(){
  const weekends = [];
  let d = new Date(2026, 8, 1);
  while (d.getDay() !== 6) d.setDate(d.getDate() + 1);
  const fin = new Date(2027, 6, 1);
  while (d < fin) {
    const sam = new Date(d);
    const dim = new Date(d); dim.setDate(dim.getDate() + 1);
    const iso = sam.getFullYear() + '-' + String(sam.getMonth()+1).padStart(2,'0') + '-' + String(sam.getDate()).padStart(2,'0');
    weekends.push({ iso, sam, dim });
    d.setDate(d.getDate() + 7);
  }
  return weekends;
}
const WEEKENDS = genererWeekends();

function libelleWeekend(w){
  const memeMois = w.sam.getMonth() === w.dim.getMonth();
  if (memeMois) return w.sam.getDate() + '–' + w.dim.getDate();
  return w.sam.getDate() + ' ' + MOIS_FR[w.sam.getMonth()].slice(0,4) + '. – ' + w.dim.getDate() + ' ' + MOIS_FR[w.dim.getMonth()].slice(0,4) + '.';
}
function libelleComplet(w){
  const memeMois = w.sam.getMonth() === w.dim.getMonth();
  if (memeMois) return w.sam.getDate() + '–' + w.dim.getDate() + ' ' + MOIS_FR[w.sam.getMonth()] + ' ' + w.sam.getFullYear();
  return w.sam.getDate() + ' ' + MOIS_FR[w.sam.getMonth()] + ' – ' + w.dim.getDate() + ' ' + MOIS_FR[w.dim.getMonth()] + ' ' + w.dim.getFullYear();
}

/* ================== ÉTAT PERSONNEL ================== */
/* statuts : { id: 'confirme'|'suspens'|'annule' }
   perso   : événements ajoutés à la main
   modifs  : { id: { we, nom, lieu, cat, niv } } — versions modifiées des compétitions de la saison */
const CLE = 'agenda-escrime-2026-2027-v3';
let etat = { statuts: {}, perso: [], modifs: {} };
/* mode de stockage :
   'claude' = aperçu Claude
   'api'    = serveur partagé (Worker Cloudflare) → tout le monde voit les mêmes données
   'local'  = mémoire du navigateur (chaque appareil a sa copie)
   'aucun'  = rien */
let modeStockage = 'aucun';

function appliquer(objOuJson){
  try {
    const p = typeof objOuJson === 'string' ? JSON.parse(objOuJson) : objOuJson;
    etat.statuts = p.statuts || {};
    etat.perso = p.perso || [];
    etat.modifs = p.modifs || {};
  } catch(e) { /* données illisibles : on repart de zéro */ }
}

async function chargerEtat(){
  /* 1) environnement Claude */
  if (typeof window.storage !== 'undefined' && window.storage) {
    modeStockage = 'claude';
    try {
      const r = await window.storage.get(CLE);
      if (r && r.value) appliquer(r.value);
    } catch(e) { /* première visite : clé absente */ }
    return;
  }
  /* 2) serveur partagé (Worker Cloudflare avec /api/data) */
  try {
    const rep = await fetch('api/data', { headers: { 'Accept':'application/json' } });
    if (rep.ok && (rep.headers.get('content-type') || '').includes('json')) {
      appliquer(await rep.json());
      modeStockage = 'api';
      return;
    }
  } catch(e) { /* pas de serveur : on continue */ }
  /* 3) mémoire du navigateur */
  try {
    const t = '__test_agenda__';
    localStorage.setItem(t, '1'); localStorage.removeItem(t);
    modeStockage = 'local';
    const v = localStorage.getItem(CLE);
    if (v) appliquer(v);
  } catch(e) { modeStockage = 'aucun'; }

  if (modeStockage === 'aucun') document.getElementById('noteStockage').classList.add('visible');
}
async function sauverEtat(){
  const json = JSON.stringify(etat);
  try {
    if (modeStockage === 'claude') {
      await window.storage.set(CLE, json);
    } else if (modeStockage === 'api') {
      await fetch('api/data', {
        method:'PUT',
        headers:{ 'Content-Type':'application/json' },
        body: json
      });
    } else if (modeStockage === 'local') {
      localStorage.setItem(CLE, json);
    }
  } catch(e) { console.error('Sauvegarde impossible', e); }
}

/* ================== RENDU ================== */
let filtreCat = 'tous';
let filtreNiv = 'tous';
const NOMS_CAT = { m17:'M17', m20:'M20', autre:'Autre' };
const NOMS_NIV = { regional:'Régional', national:'National', europeen:'Européen', international:'International' };
const NOMS_STATUT = { confirme:'✅ Je la fais', suspens:'🤔 En suspens', annule:'✖ Je ne la fais pas' };

function tousEvenements(){
  const saison = EVENEMENTS_SAISON.map(e => {
    const m = etat.modifs[e.id];
    return m ? Object.assign({}, e, m, { modifie:true }) : e;
  });
  return [...saison, ...etat.perso];
}

function rendre(){
  const agenda = document.getElementById('agenda');
  agenda.innerHTML = '';
  const tous = tousEvenements();

  let moisCourant = -1, conteneur = null;

  WEEKENDS.forEach(w => {
    const cleM = w.sam.getFullYear() * 100 + w.sam.getMonth();
    if (cleM !== moisCourant) {
      moisCourant = cleM;
      const blocMois = document.createElement('section');
      blocMois.className = 'mois';
      const h2 = document.createElement('h2');
      h2.innerHTML = MOIS_FR[w.sam.getMonth()] + ' <em>' + w.sam.getFullYear() + '</em>';
      blocMois.appendChild(h2);
      conteneur = document.createElement('div');
      blocMois.appendChild(conteneur);
      agenda.appendChild(blocMois);
    }

    let evts = tous.filter(e => e.we === w.iso);
    if (filtreCat !== 'tous') evts = evts.filter(e => e.cat === filtreCat);
    if (filtreNiv !== 'tous') evts = evts.filter(e => (e.niv || '') === filtreNiv);

    const ligne = document.createElement('div');
    ligne.className = 'weekend ' + (evts.length ? 'occupe' : 'libre');

    const dates = document.createElement('div');
    dates.className = 'dates';
    dates.innerHTML = libelleWeekend(w) + '<small>sam · dim</small>';
    ligne.appendChild(dates);

    if (evts.length === 0) {
      const lib = document.createElement('div');
      lib.className = 'libre-label';
      lib.textContent = 'Week-end libre';
      ligne.appendChild(lib);
    } else {
      const col = document.createElement('div');
      col.className = 'evts';
      evts.forEach(e => {
        const statut = etat.statuts[e.id] || '';
        const carte = document.createElement('button');
        carte.type = 'button';
        carte.className = 'evt ' + e.cat + (statut ? ' statut-' + statut : '');
        carte.setAttribute('aria-label', e.nom + ' — cliquer pour modifier');
        let badges = '<span class="badge ' + e.cat + '">' + NOMS_CAT[e.cat] + '</span>';
        if (e.niv) badges += '<span class="badge niv ' + e.niv + '">' + NOMS_NIV[e.niv] + '</span>';
        if (statut) badges += '<span class="badge st-' + statut + '">' + NOMS_STATUT[statut] + '</span>';
        carte.innerHTML =
          '<span class="lampe-touche" aria-hidden="true"></span>' +
          '<div class="evt-corps"><div class="evt-nom"></div><div class="evt-lieu"></div></div>' +
          '<div class="badges">' + badges + '</div>';
        carte.querySelector('.evt-nom').textContent = e.nom;
        carte.querySelector('.evt-lieu').textContent = e.lieu || '';
        carte.addEventListener('click', () => ouvrirMenu(e));
        col.appendChild(carte);
      });
      ligne.appendChild(col);
    }
    conteneur.appendChild(ligne);
  });
}

/* ================== FILTRES (catégorie + niveau, combinables) ================== */
document.querySelectorAll('.chip').forEach(c => {
  c.addEventListener('click', () => {
    const type = c.dataset.type;
    document.querySelectorAll('.chip[data-type="' + type + '"]').forEach(x => x.classList.remove('actif'));
    c.classList.add('actif');
    if (type === 'cat') filtreCat = c.dataset.filtre;
    else filtreNiv = c.dataset.filtre;
    rendre();
  });
});

/* ================== MODALE MENU (au clic sur une compétition) ================== */
const voileMenu = document.getElementById('voileMenu');
const voileStatut = document.getElementById('voileStatut');
const voileAjout = document.getElementById('voileAjout');
let evtCourant = null;

function descriptionEvt(e){
  const w = WEEKENDS.find(x => x.iso === e.we);
  return NOMS_CAT[e.cat]
    + (e.niv ? ' · ' + NOMS_NIV[e.niv] : '')
    + (e.lieu ? ' · ' + e.lieu : '')
    + (w ? ' · ' + libelleComplet(w) : '');
}

function ouvrirMenu(e){
  evtCourant = e;
  document.getElementById('titreMenu').textContent = e.nom;
  document.getElementById('sousTitreMenu').textContent = descriptionEvt(e);
  document.getElementById('btnSupprEvt').style.display = e.perso ? 'block' : 'none';
  voileMenu.classList.add('ouvert');
}
document.getElementById('btnFermerMenu').addEventListener('click', () => voileMenu.classList.remove('ouvert'));
voileMenu.addEventListener('click', e => { if (e.target === voileMenu) voileMenu.classList.remove('ouvert'); });

document.getElementById('btnVersStatut').addEventListener('click', () => {
  voileMenu.classList.remove('ouvert');
  ouvrirStatut(evtCourant);
});
document.getElementById('btnVersEdition').addEventListener('click', () => {
  voileMenu.classList.remove('ouvert');
  ouvrirEdition(evtCourant);
});
document.getElementById('btnSupprEvt').addEventListener('click', async () => {
  if (!evtCourant || !evtCourant.perso) return;
  etat.perso = etat.perso.filter(x => x.id !== evtCourant.id);
  delete etat.statuts[evtCourant.id];
  await sauverEtat();
  voileMenu.classList.remove('ouvert');
  rendre();
});

/* ================== MODALE STATUT ================== */
function ouvrirStatut(e){
  if (!e) return;
  evtCourant = e;
  document.getElementById('titreStatut').textContent = e.nom;
  document.getElementById('sousTitreStatut').textContent = descriptionEvt(e);
  const statut = etat.statuts[e.id] || '';
  document.querySelectorAll('#statutListe button').forEach(b => {
    b.classList.toggle('select', b.dataset.statut === statut);
  });
  voileStatut.classList.add('ouvert');
}
document.querySelectorAll('#statutListe button').forEach(b => {
  b.addEventListener('click', async () => {
    if (!evtCourant) return;
    const s = b.dataset.statut;
    if (s) etat.statuts[evtCourant.id] = s;
    else delete etat.statuts[evtCourant.id];
    await sauverEtat();
    voileStatut.classList.remove('ouvert');
    rendre();
  });
});
document.getElementById('btnFermerStatut').addEventListener('click', () => voileStatut.classList.remove('ouvert'));
voileStatut.addEventListener('click', e => { if (e.target === voileStatut) voileStatut.classList.remove('ouvert'); });

/* ================== MODALE AJOUT / ÉDITION ================== */
const selWeekend = document.getElementById('selWeekend');
let catSelection = 'm17';
let nivSelection = 'regional';
let modeEdition = false;   // false = ajout, true = édition de evtCourant

WEEKENDS.forEach(w => {
  const opt = document.createElement('option');
  opt.value = w.iso;
  opt.textContent = libelleComplet(w);
  selWeekend.appendChild(opt);
});

function choisirCat(cat){
  catSelection = cat;
  document.querySelectorAll('#catChoix button').forEach(x => x.classList.toggle('actif', x.dataset.cat === cat));
}
function choisirNiv(niv){
  nivSelection = niv;
  document.querySelectorAll('#nivChoix button').forEach(x => x.classList.toggle('actif', x.dataset.niv === niv));
}
document.querySelectorAll('#catChoix button').forEach(b => b.addEventListener('click', () => choisirCat(b.dataset.cat)));
document.querySelectorAll('#nivChoix button').forEach(b => b.addEventListener('click', () => choisirNiv(b.dataset.niv)));

function ouvrirAjout(){
  modeEdition = false;
  document.getElementById('titreAjout').textContent = 'Ajouter un événement';
  document.getElementById('btnValider').textContent = 'Ajouter';
  document.getElementById('btnRetablir').style.display = 'none';
  document.getElementById('inpNom').value = '';
  document.getElementById('inpLieu').value = '';
  selWeekend.value = WEEKENDS[0].iso;
  choisirCat('m17'); choisirNiv('regional');
  voileAjout.classList.add('ouvert');
  document.getElementById('inpNom').focus();
}

function ouvrirEdition(e){
  if (!e) return;
  evtCourant = e;
  modeEdition = true;
  document.getElementById('titreAjout').textContent = 'Modifier la compétition';
  document.getElementById('btnValider').textContent = 'Enregistrer';
  document.getElementById('inpNom').value = e.nom;
  document.getElementById('inpLieu').value = e.lieu || '';
  selWeekend.value = e.we;
  choisirCat(e.cat); choisirNiv(e.niv || 'regional');
  /* proposer de rétablir l'original si c'est une compétition de la saison déjà modifiée */
  document.getElementById('btnRetablir').style.display = (!e.perso && etat.modifs[e.id]) ? 'block' : 'none';
  voileAjout.classList.add('ouvert');
  document.getElementById('inpNom').focus();
}

document.getElementById('btnOuvrir').addEventListener('click', ouvrirAjout);
document.getElementById('btnAnnulerAjout').addEventListener('click', () => voileAjout.classList.remove('ouvert'));
voileAjout.addEventListener('click', e => { if (e.target === voileAjout) voileAjout.classList.remove('ouvert'); });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    voileAjout.classList.remove('ouvert');
    voileStatut.classList.remove('ouvert');
    voileMenu.classList.remove('ouvert');
  }
});

document.getElementById('btnRetablir').addEventListener('click', async () => {
  if (!evtCourant || evtCourant.perso) return;
  delete etat.modifs[evtCourant.id];
  await sauverEtat();
  voileAjout.classList.remove('ouvert');
  rendre();
});

document.getElementById('btnValider').addEventListener('click', async () => {
  const nom = document.getElementById('inpNom').value.trim();
  const lieu = document.getElementById('inpLieu').value.trim();
  if (!nom) { document.getElementById('inpNom').focus(); return; }

  if (modeEdition && evtCourant) {
    if (evtCourant.perso) {
      /* événement ajouté à la main : on le met à jour directement */
      const cible = etat.perso.find(x => x.id === evtCourant.id);
      if (cible) Object.assign(cible, { we:selWeekend.value, nom, lieu, cat:catSelection, niv:nivSelection });
    } else {
      /* compétition de la saison : on enregistre une version modifiée */
      etat.modifs[evtCourant.id] = { we:selWeekend.value, nom, lieu, cat:catSelection, niv:nivSelection };
    }
  } else {
    etat.perso.push({
      id: 'p' + Date.now(),
      we: selWeekend.value,
      cat: catSelection,
      niv: nivSelection,
      nom, lieu,
      perso: true
    });
  }
  await sauverEtat();
  voileAjout.classList.remove('ouvert');
  rendre();
});

/* ================== DÉMARRAGE ================== */
(async () => { await chargerEtat(); rendre(); })();
</script>
</body>
</html>
`;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    /* ---- API de données partagées ---- */
    if (url.pathname === "/api/data") {
      if (request.method === "GET") {
        const brut = env.AGENDA ? await env.AGENDA.get(CLE_DONNEES) : null;
        return new Response(brut || "{}", {
          headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
        });
      }
      if (request.method === "PUT") {
        if (!env.AGENDA) {
          return new Response('{"erreur":"Binding KV AGENDA manquant"}', {
            status: 500, headers: { "Content-Type": "application/json" }
          });
        }
        const corps = await request.text();
        if (corps.length > 200000) {
          return new Response('{"erreur":"Donnees trop volumineuses"}', {
            status: 413, headers: { "Content-Type": "application/json" }
          });
        }
        try { JSON.parse(corps); } catch (e) {
          return new Response('{"erreur":"JSON invalide"}', {
            status: 400, headers: { "Content-Type": "application/json" }
          });
        }
        await env.AGENDA.put(CLE_DONNEES, corps);
        return new Response('{"ok":true}', {
          headers: { "Content-Type": "application/json" }
        });
      }
      return new Response("Methode non autorisee", { status: 405 });
    }

    /* ---- La page de l'agenda ---- */
    return new Response(PAGE_HTML, {
      headers: { "Content-Type": "text/html; charset=utf-8" }
    });
  }
};
